# bl/business_logic.py

from dal.database_access import MealPlannerDAL

# MealPlannerBL class in bl/business_logic.py

class MealPlannerBL:
    def __init__(self, dal: MealPlannerDAL):
        self.dal = dal

    def display_cookbooks(self):
        cookbooks = self.dal.get_all_cookbooks()
        if cookbooks:
            print("\nAvailable Cookbooks:")
            for cookbook in cookbooks:
                print(f"- ID: {cookbook['cookbook_id']}, Name: {cookbook['name']}")
        else:
            print("No cookbooks found.")

    def display_recipes_for_cookbook(self, cookbook_id):
        recipes = self.dal.get_recipes_by_cookbook(cookbook_id)
        if recipes:
            print(f"\nRecipes for Cookbook ID {cookbook_id}:")
            for recipe in recipes:
                print(f"- ID: {recipe['recipe_id']}, Name: {recipe['name']}")
        else:
            print(f"No recipes found for Cookbook ID {cookbook_id}.")

    def display_ingredients_for_recipe(self, recipe_id):
        ingredients = self.dal.get_ingredients_for_recipe(recipe_id)
        if ingredients:
            print(f"\nIngredients for Recipe ID {recipe_id}:")
            for ingredient in ingredients:
                print(f"- {ingredient['name']} : {ingredient['quantity']}")
        else:
            print(f"No ingredients found for Recipe ID {recipe_id}.")


    def assign_recipe_to_day(self, recipe_id, day):
        success, message = self.dal.assign_recipe_to_day(recipe_id, day)
        print(message)

