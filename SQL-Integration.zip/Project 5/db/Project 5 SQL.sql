DROP DATABASE IF EXISTS Project5;

CREATE DATABASE Project5;

USE  Project5;


CREATE TABLE Cookbooks (
    cookbook_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

INSERT INTO Cookbooks (name, cookbook_id) VALUES ('Top 10 Italian Foods', 1);
INSERT INTO Cookbooks (name, cookbook_id) VALUES ('Easy 2 Cook: Mexican Food', 2);
INSERT INTO Cookbooks (name, cookbook_id) VALUES ('Best American Subs', 3);
INSERT INTO Cookbooks (name, cookbook_id) VALUES ('Neighborhood Cookout Essentials', 4);
INSERT INTO Cookbooks (name, cookbook_id) VALUES ('Food For Your Lunchbox', 5);

CREATE TABLE Recipes (
    recipe_id INT AUTO_INCREMENT PRIMARY KEY,
    cookbook_id INT,
    name VARCHAR(255) NOT NULL,
    FOREIGN KEY (cookbook_id) REFERENCES Cookbooks(cookbook_id)
);

INSERT INTO Recipes (cookbook_id, name) VALUES (1, 'Pizza');
INSERT INTO Recipes (cookbook_id, name) VALUES (2, 'Quesadilla');
INSERT INTO Recipes (cookbook_id, name) VALUES (3, 'Ham & Cheese Sub');
INSERT INTO Recipes (cookbook_id, name) VALUES (4, 'Cheese Burger');
INSERT INTO Recipes (cookbook_id, name) VALUES (5, 'Chicken Sandwhich');

CREATE TABLE IF NOT EXISTS Ingredients (
    ingredient_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

INSERT INTO Ingredients (name) VALUES ('Cheese'); -- 1
INSERT INTO Ingredients (name) VALUES ('Tomato Sauce'); -- 2
INSERT INTO Ingredients (name) VALUES ('Dough'); -- 3
INSERT INTO Ingredients (name) VALUES ('Tortilla'); -- 4
INSERT INTO Ingredients (name) VALUES ('Chicken'); -- 5
INSERT INTO Ingredients (name) VALUES ('Pepperoni'); -- 6
INSERT INTO Ingredients (name) VALUES ('Bread'); -- 7
INSERT INTO Ingredients (name) VALUES ('Beef'); -- 8
INSERT INTO Ingredients (name) VALUES ('Ham'); -- 9
INSERT INTO Ingredients (name) VALUES ('Mayonaise'); -- 10
INSERT INTO Ingredients (name) VALUES ('Pickles'); -- 11
INSERT INTO Ingredients (name) VALUES ('Pepperoni'); -- 12
INSERT INTO Ingredients (name) VALUES ('Ketchup'); -- 13
INSERT INTO Ingredients (name) VALUES ('Mustard'); -- 14
INSERT INTO Ingredients (name) VALUES ('Lettuce'); -- 15

CREATE TABLE RecipeIngredients (
    recipe_id INT,
    ingredient_id INT,
    quantity VARCHAR(255),
    FOREIGN KEY (recipe_id) REFERENCES Recipes(recipe_id),
    FOREIGN KEY (ingredient_id) REFERENCES Ingredients(ingredient_id),
    PRIMARY KEY (recipe_id, ingredient_id)
);

INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (1, 1, 'Quantity 10');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (1, 2, 'Quantity 5');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (1, 3, 'Quantity 10');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (1, 6, 'Quantity 10');

INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (2, 1, 'Quantity 5');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (2, 4, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (2, 5, 'Quantity 2');


INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (3, 1, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (3, 7, 'Quantity 3');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (3, 9, 'Quantity 3');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (3, 10, 'Quantity 2');



INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 1, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 7, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 8, 'Quantity 1');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 10, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 11, 'Quantity 3');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 13, 'Quantity 1');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 14, 'Quantity 1');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (4, 15, 'Quantity 1');

INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (5, 5, 'Quantity 1');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (5, 7, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (5, 10, 'Quantity 2');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (5, 11, 'Quantity 3');
INSERT INTO RecipeIngredients (recipe_id, ingredient_id, quantity) VALUES (5, 15, 'Quantity 1');

CREATE TABLE MealPlan (
    day DATE NOT NULL,
    recipe_id INT,
    FOREIGN KEY (recipe_id) REFERENCES Recipes(recipe_id),
    PRIMARY KEY (day, recipe_id)
);

INSERT INTO MealPlan (day, recipe_id) VALUES ('2024-04-10', 1);


DELIMITER //

CREATE PROCEDURE `SelectRecipesByCookbook`(IN `cb_id` INT)
BEGIN
    SELECT * FROM Recipes WHERE cookbook_id = cb_id;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE `SelectAllCookbooks`()
BEGIN
    SELECT * FROM Cookbooks;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE `SelectIngredientsForRecipe`(IN `r_id` INT)
BEGIN
    SELECT Ingredients.name, RecipeIngredients.quantity 
    FROM Ingredients
    JOIN RecipeIngredients ON Ingredients.ingredient_id = RecipeIngredients.ingredient_id
    WHERE RecipeIngredients.recipe_id = r_id;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE `AssignRecipeToDay`(IN `r_id` INT, IN `day` DATE)
BEGIN
    -- Check if the recipe is already assigned to the day
    IF NOT EXISTS (SELECT 1 FROM MealPlan WHERE recipe_id = r_id AND day = day) THEN
        INSERT INTO MealPlan(day, recipe_id) VALUES (day, r_id);
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This recipe is already assigned to the selected day.';
    END IF;
END //

DELIMITER ;

GRANT ALL PRIVILEGES ON `Project 5 SQL`.* TO 'user'@'localhost';

SELECT * FROM MealPlan;

