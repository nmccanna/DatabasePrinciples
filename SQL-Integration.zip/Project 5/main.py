# main.py
from dal.database_access import MealPlannerDAL
from pl.presentation_logic import run
from bl.business_logic import MealPlannerBL

# Database configuration
db_config = {
    'user': 'user',
    'password': 'password',
    'host': 'localhost',
    'database': 'Project5',
}

if __name__ == '__main__':
    dal = MealPlannerDAL(db_config)
    run(dal)