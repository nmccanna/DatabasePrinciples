# dal/database_access.py

import mysql.connector
from mysql.connector import Error

# DAL class in dal/database_access.py

class MealPlannerDAL:
    def __init__(self, db_config):
        self.db_config = db_config

    def connect(self):
        try:
            self.cnx = mysql.connector.connect(**self.db_config)
            self.cursor = self.cnx.cursor(dictionary=True)
        except Error as e:
            print(f"Error connecting to MySQL Platform: {e}")
            self.cnx = None

    def close(self):
        if self.cnx:
            self.cursor.close()
            self.cnx.close()

    def get_all_cookbooks(self):
        self.connect()
        self.cursor.callproc('SelectAllCookbooks')
        result = []
        for result_set in self.cursor.stored_results():
            result = result_set.fetchall()
        self.close()
        return result

    def get_recipes_by_cookbook(self, cookbook_id):
        self.connect()
        self.cursor.callproc('SelectRecipesByCookbook', [cookbook_id])
        result = []
        for result_set in self.cursor.stored_results():
            result = result_set.fetchall()
        self.close()
        return result

    def get_ingredients_for_recipe(self, recipe_id):
        self.connect()
        self.cursor.callproc('SelectIngredientsForRecipe', [recipe_id])
        result = []
        for result_set in self.cursor.stored_results():
            result = [row for row in result_set]
        self.close()
        return result

    def assign_recipe_to_day(self, recipe_id, day):
        self.connect()
        try:
            self.cursor.callproc('AssignRecipeToDay', [recipe_id, day])
            self.cnx.commit()  # Commit changes to the database
            return True, "Recipe successfully assigned to the day."
        except mysql.connector.Error as err:
            # Check if the error is because the recipe is already assigned to the day
            if err.errno == 1644:
                return False, "This recipe is already assigned to the selected day."
            else:
                return False, f"Database error: {err}"
        finally:
            self.close()


    