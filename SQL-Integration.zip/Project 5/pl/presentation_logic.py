# pl/presentation_logic.py

from bl.business_logic import MealPlannerBL

# Main menu function in pl/presentation_logic.py

def main_menu():
    print("\nMain Menu:")
    print("1. View Cookbooks")
    print("2. View Recipes in a Cookbook")
    print("3. View Ingredients for a Recipe")
    print("4. Assign a Recipe to a Day")
    choice = input("Choose an option: ")
    return choice


def run(dal):
    bl = MealPlannerBL(dal)
    while True:
        choice = main_menu()
        if choice == '1':
            bl.display_cookbooks()
        elif choice == '2':
            cookbook_id = input("Enter Cookbook ID: ")
            bl.display_recipes_for_cookbook(cookbook_id)
        elif choice == '3':
            recipe_id = view_ingredients_menu()
            bl.display_ingredients_for_recipe(int(recipe_id))
        elif choice == '4':
            assign_recipe_to_day_menu(bl)
        else:
            print("Invalid choice. Please try again.")

def view_ingredients_menu():
    recipe_id = input("Enter Recipe ID to view ingredients: ")
    return recipe_id

def assign_recipe_to_day_menu(bl):
    try:
        recipe_id = int(input("Enter Recipe ID: "))
        day = input("Enter the day for this recipe (YYYY-MM-DD): ")
        bl.assign_recipe_to_day(recipe_id, day)
    except ValueError:
        print("Invalid input. Please try again.")


if __name__ == '__main__':
    run()




