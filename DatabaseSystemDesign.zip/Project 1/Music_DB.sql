DROP DATABASE IF EXISTS music_db;
CREATE DATABASE music_db;
USE music_db;

CREATE TABLE Artists (
    ArtistID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255) NOT NULL,
    Country VARCHAR(255),
    Genre VARCHAR(255)
);

CREATE TABLE Albums (
    AlbumID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    ArtistID INT,
    ReleaseDate DATE,
    Genre VARCHAR(255),
    FOREIGN KEY (ArtistID) REFERENCES Artists(ArtistID)
);

CREATE TABLE Tracks (
    TrackID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    AlbumID INT,
    Duration TIME,
    TrackNumber INT,
    FOREIGN KEY (AlbumID) REFERENCES Albums(AlbumID)
);


INSERT INTO Artists (ArtistID, Name, Country, Genre)
VALUES
(1, 'Jay-Z', 'United States', 'HipHop'),
(2, 'Alicia Keys', 'United States', 'R&B'),
(3, 'AC/DC', 'Australia', 'Rock'),
(4, 'Mozart', 'Austria', 'Classical'),
(5, 'Deadmou5', 'Canada', 'Electronic');

INSERT INTO Albums (AlbumID, Title, ArtistID, ReleaseDate, Genre)
VALUES
(1, 'The Black Album', 1, '2005-11-14', 'HipHop'),
(2, 'HERE', 2, '2016-11-04', 'R&B'),
(3, 'Back in Black', 3, '1980-07-25', 'Rock'),
(4, 'Requiem', 4, '1792-02-14', 'Classical'),
(5, 'Project 56', 5, '2008-02-19', 'Electronic');

INSERT INTO Tracks (TrackID, Title, AlbumID, Duration, TrackNumber)
VALUES
(1, 'Encore', 1, 4.10, 4),
(2, 'Blended Family', 2, 3.31, 9),
(3, 'Hells Bells', 3, 5.12, 1),
(4, 'Kyrie', 4, 2.55, 2),
(5, '15 Minutes', 5, 15.00, 1);