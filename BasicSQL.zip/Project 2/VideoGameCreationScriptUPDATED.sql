/* CSC6302 Database Principles
	Unit Two: Basic SQL
    Professor Minton
*/

DROP DATABASE IF EXISTS VideoGameSystems;
CREATE DATABASE VideoGameSystems;

USE VideoGameSystems;

-- (MCCANNA) Modified Console table by removing the Developer column.

CREATE TABLE IF NOT EXISTS Console(
ConsoleName varchar(100) not null,
ReleaseDate Date not null,
SystemRevision double not null,
Primary Key (ConsoleName),
CONSTRAINT ValidConsoleReleaseDate CHECK (ReleaseDate BETWEEN "1975-08-12" and "2022-02-02")
);

-- (MCCANNA) Modified the insert statements for Console by removing the Developer column.

INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Atari", "1975-08-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Atari 2600", "1977-12-01", 2.07);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Nintendo Entertainment System", "1983-07-15", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Sega Genesis", "1988-10-29", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Game Gear", "1990-10-06", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Sega Saturn", "1988-08-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Sega Dreamcast", "1998-11-27", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("SG-100", "1983-07-15", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Master System", "1985-010-06", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Sega CD", "1991-12-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Game Boy", "1975-08-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Game Boy Color", "1975-08-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Super Nintendo", "1990-11-21", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Nintendo 64", "1996-07-23", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Game Cube", "2001-11-05", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Wii", "2006-11-19", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Wii U", "2012-11-18", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Game Boy Advance", "1975-08-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Switch", "2017-03-03", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Nintendo 3DS", "2010-06-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Nintendo DS", "2004-08-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Play Station", "1994-12-03", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Play Station 2", "2000-12-28", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Play Station 3", "2006-11-11", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Play Station 4", "2013-02-20", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Play Station 5", "2020-11-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("Play Station Portable", "2004-12-12", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("XBox", "2001-11-15", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("XBox 360", "2005-11-15", 4.01);
INSERT INTO Console (ConsoleName, ReleaseDate, SystemRevision) VALUES ("XBox One", "2016-06-13", 4.01);

-- (MCCANNA) Created the Developers table.

CREATE TABLE IF NOT EXISTS Developers(
    DeveloperID INT AUTO_INCREMENT,
    DeveloperName varchar(200) NOT NULL,
    PRIMARY KEY (DeveloperID)
);

-- (MCCANNA) Insert statements for Developers table.

INSERT INTO Developers (DeveloperName) VALUES ('Atari');
INSERT INTO Developers (DeveloperName) VALUES ('Nintendo');
INSERT INTO Developers (DeveloperName) VALUES ('Sony');
INSERT INTO Developers (DeveloperName) VALUES ('Activision');
INSERT INTO Developers (DeveloperName) VALUES ('Sega');


-- (MCCANNA) Created a new Games table to update the Game table.

CREATE TABLE IF NOT EXISTS Games(
    GameID INT AUTO_INCREMENT,
    Title varchar(200) NOT NULL,
    ReleaseDate Date NOT NULL,
    DeveloperID INT,
    PRIMARY KEY (GameID),
    FOREIGN KEY (DeveloperID) REFERENCES Developers(DeveloperID)
);

-- (MCCANNA) Insert statements for Games table.

INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Animal Crossing", "2001-04-14", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Wild World", "2005-11-15", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("City Folk", "2011-11-09", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("New Leaf", "2013-06-12", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Happy Home Designer", "2015-07-05", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Amiibo Festival", "2015-11-13", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("New Horizons", "2020-03-20", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("New Horizons Happy Home Paradise", "2021-11-05", 2);

INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi", "1991-04-01", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Cookie", "1992-06-23", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Safari", "1995-01-21", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Island", "1995-11-19", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Story", "1997-04-07", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Universal Gravitation", "2004-11-09", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi Touch and Go", "2005-12-27", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Wooly World", "2015-06-15", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Island", "2016-11-13", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Poochy and Yoshi's Wooly World", "1991-11-09", 2);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Yoshi's Crafted World", "2019-03-29", 2);

INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty", "2003-10-29", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty", "2003-10-29", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 2", "2005-10-25", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 3", "2006-11-07", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 3", "2006-11-07", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 3", "2006-11-07", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 3", "2006-11-07", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 3", "2006-11-07", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 4", "2006-11-07", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 4: Modern Warfare", "2007-11-06", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 4: Modern Warfare", "2007-11-06", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty 4: Modern Warfare", "2007-11-06", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty: World at War", "2011-11-11", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty: World at War", "2011-11-11", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty: World at War", "2011-11-11", 4);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Call of Duty: World at War", "2011-11-11", 4);

INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic the Hedgehog", "1991-11-09", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic the Hedgehog 2", "1992-11-09", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic the Hedgehog 3", "1994-11-21", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Adventures", "1991-11-09", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Adventure 2 Battle", "1998-11-13", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Heroes", "2003-11-09", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Heroes", "2003-11-09", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Heroes", "2003-11-09", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Unleashed", "2008-06-29", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Unleashed", "2008-06-29", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Unleashed", "2008-06-29", 5);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Sonic Unleashed", "2008-06-29", 5);

INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Spyro the Dragon", "1998-09-09", 3);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Spyro's Adventure", "2011-10-13", 3);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Spyro's Adventure", "2011-10-13", 3);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Spyro's Adventure", "2011-10-13", 3);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Spyro's Adventure", "2011-10-13", 3);
INSERT INTO Games (Title, ReleaseDate, DeveloperID) VALUES ("Spyro's Adventure", "2011-10-13", 3);


-- (MCCANNA) Created a GameReleases table for tracking game releases on different consoles.

CREATE TABLE IF NOT EXISTS GameReleases(
    GameID INT,
    ConsoleName varchar(100),
    ReleaseDate Date NOT NULL,
    PRIMARY KEY (GameID, ConsoleName),
    FOREIGN KEY (GameID) REFERENCES Games(GameID),
    FOREIGN KEY (ConsoleName) REFERENCES Console(ConsoleName)
);

-- (MCCANNA) Insert statements for GameReleases table.

INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (1, 'Nintendo 64', '2001-04-14');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (2, 'Nintendo DS', '2005-11-15');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (3, 'Wii', '2011-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (4, 'Nintendo 3DS', '2013-06-12');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (5, 'Nintendo 3DS', '2015-07-05');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (6, 'Wii U', '2015-11-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (7, 'Switch', '2020-03-20');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (8, 'Switch', '2021-11-05');

INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (9, 'Nintendo Entertainment System', '1991-04-01');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (10, 'Nintendo Entertainment System', '1992-06-23');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (11, 'Super Nintendo', '1995-01-21');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (12, 'Super Nintendo', '1995-11-19');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (13, 'Nintendo 64', '1997-04-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (14, 'Game Boy Advance', '2004-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (15, 'Nintendo DS', '2005-12-27');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (16, 'Wii U', '2015-06-15');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (17, 'Nintendo DS', '2016-11-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (18, 'Nintendo DS', '1991-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (19, 'Switch', '2019-03-29');

INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (20, 'XBox 360', '2003-10-29');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (20, 'Play Station 3', '2003-10-29');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (21, 'XBox 360', '2005-10-25');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (22, 'Play Station 2', '2006-11-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (22, 'Play Station 3', '2006-11-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (22, 'Wii', '2006-11-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (22, 'XBox', '2006-11-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (22, 'XBox 360', '2006-11-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (23, 'Nintendo DS', '2006-11-07');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (23, 'XBox', '2007-11-06');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (23, 'Play Station 3', '2007-11-06');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (23, 'Wii', '2007-11-06');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (24, 'XBox 360', '2011-11-11');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (24, 'Nintendo DS', '2011-11-11');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (24, 'Play Station 3', '2011-11-11');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (24, 'Wii', '2011-11-11');

INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (25, 'Sega Genesis', '1991-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (26, 'Sega Genesis', '1992-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (27, 'Sega Genesis', '1994-11-21');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (28, 'Sega Dreamcast', '1991-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (29, 'Game Cube', '1998-11-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (30, 'Play Station 2', '2003-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (30, 'XBox', '2003-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (30, 'Game Cube', '2003-11-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (31, 'Play Station 2', '2008-06-29');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (31, 'Wii', '2008-06-29');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (31, 'XBox 360', '2008-06-29');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (31, 'Play Station 3', '2008-06-29');

INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (32, 'Play Station', '1998-09-09');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (33, 'Wii', '2011-10-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (33, 'Nintendo DS', '2011-10-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (33, 'Play Station 3', '2011-10-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (33, 'Wii U', '2011-10-13');
INSERT INTO GameReleases (GameID, ConsoleName, ReleaseDate) VALUES (33, 'XBox 360', '2011-10-13');

CREATE TABLE IF NOT EXISTS Series(
Id int auto_increment not null,
SeriesName varchar(200) not null,
PRIMARY KEY (Id)
);

INSERT INTO Series (SeriesName) VALUES ("Animal Crossing");
INSERT INTO Series (SeriesName) VALUES ("Yoshi");
INSERT INTO Series (SeriesName) VALUES ("Final Fantasy");
INSERT INTO Series (SeriesName) VALUES ("Call of Duty");
INSERT INTO Series (SeriesName) VALUES ("Kingdom Hearts");
INSERT INTO Series (SeriesName) VALUES ("Sonic");
INSERT INTO Series (SeriesName) VALUES ("Spyro");

CREATE TABLE  IF NOT EXISTS Game(
Id int not null auto_increment,
GameName varchar(200) not null,
ReleaseDate Date not null,
ConsoleName varchar(100) not null,
Series int,
NumPlayers int,
IsOnline bool,
PRIMARY KEY (Id),
FOREIGN KEY (ConsoleName) REFERENCES Console (ConsoleName)
 ON DELETE CASCADE
ON UPDATE CASCADE,
FOREIGN KEY (Series) REFERENCES Series (Id),
CONSTRAINT ValidGameReleaseDate CHECK (ReleaseDate BETWEEN "1975-08-12" and "2022-02-02")
);

INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Animal Crossing", "2001-04-14", "Nintendo 64", 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Wild World", "2005-11-15", "Nintendo DS", 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("City Folk", "2011-11-09", "Wii", 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("New Leaf", "2013-06-12", "Nintendo 3DS", 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Happy Home Designer", "2015-07-05", "Nintendo 3DS", 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Amiibo Festival", "2015-11-13", "Wii U", 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, IsOnline, Series) VALUES ("New Horizons", "2020-03-20", "Switch", true, 1);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, IsOnline, Series) VALUES ("New Horizons Happy Home Paradise", "2021-11-05", "Switch", true, 1);

INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi", "1991-04-01", "Nintendo Entertainment System");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Cookie", "1992-06-23", "Nintendo Entertainment System");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Safari", "1995-01-21", "Super Nintendo");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Island", "1995-11-19", "Super Nintendo");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Story", "1997-04-07", "Nintendo 64");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Universal Gravitation", "2004-11-09", "Game Boy Advance");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi Touch and Go", "2005-12-27", "Nintendo DS");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Wooly World", "2015-06-15", "Wii U");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Island", "2016-11-13", "Nintendo DS");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Poochy and Yoshi's Wooly World", "1991-11-09", "Nintendo 3DS");
INSERT INTO Game (GameName, ReleaseDate, ConsoleName) VALUES ("Yoshi's Crafted World", "2019-03-29", "Switch");

INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty", "2003-10-29", "XBox 360", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty", "2003-10-29", "Play Station 3", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 2", "2005-10-25", "XBox 360", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 3", "2006-11-07", "Play Station 2", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 3", "2006-11-07", "Play Station 3", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 3", "2006-11-07", "Wii", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 3", "2006-11-07", "XBox", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 3", "2006-11-07", "XBox 360", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 4", "2006-11-07", "Nintendo DS", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 4: Modern Warfare", "2007-11-06", "XBox", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 4: Modern Warfare", "2007-11-06", "Play Station 3", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty 4: Modern Warfare", "2007-11-06", "Wii", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty: World at War", "2011-11-11", "XBox 360", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty: World at War", "2011-11-11", "Nintendo DS", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty: World at War", "2011-11-11", "Play Station 3", 4);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Call of Duty: World at War", "2011-11-11", "Wii", 4);

INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic the Hedgehog", "1991-11-09", "Sega Genesis", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic the Hedgehog 2", "1992-11-09", "Sega Genesis", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic the Hedgehog 3", "1994-11-21", "Sega Genesis", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Adventures", "1991-11-09", "Sega Dreamcast", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Adventure 2 Battle", "1998-11-13", "Game Cube", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Heroes", "2003-11-09", "Play Station 2", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Heroes", "2003-11-09", "XBox", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Heroes", "2003-11-09", "Game Cube", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Unleashed", "2008-06-29", "Play Station 2", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Unleashed", "2008-06-29", "Wii", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Unleashed", "2008-06-29", "XBox 360", 6);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Sonic Unleashed", "2008-06-29", "Play Station 3", 6);

INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Spyro the Dragon", "1998-09-09", "Play Station", 7);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Spyro's Adventure", "2011-10-13", "Wii", 7);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Spyro's Adventure", "2011-10-13", "Nintendo DS", 7);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Spyro's Adventure", "2011-10-13", "Play Station 3", 7);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Spyro's Adventure", "2011-10-13", "Wii U", 7);
INSERT INTO Game (GameName, ReleaseDate, ConsoleName, Series) VALUES ("Spyro's Adventure", "2011-10-13", "XBox 360", 7);

