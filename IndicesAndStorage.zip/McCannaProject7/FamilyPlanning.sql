-- Use 'IF NOT EXISTS' to ensure idempotence for running the script multiple times
CREATE DATABASE IF NOT EXISTS FamilyPlanning;

USE FamilyPlanning;

-- Drop the tables if they exist to allow the script to run multiple times
DROP TABLE IF EXISTS reminders;
DROP TABLE IF EXISTS tasks;
DROP TABLE IF EXISTS activities;
DROP TABLE IF EXISTS users;

-- Table creation
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE activities (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    frequency ENUM('daily', 'weekly', 'monthly') NOT NULL,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    activity_id INT,
    assigned_to INT,
    status ENUM('completed', 'pending', 'canceled') NOT NULL,
    due_date DATETIME NOT NULL,
    FOREIGN KEY (activity_id) REFERENCES activities(activity_id),
    FOREIGN KEY (assigned_to) REFERENCES users(user_id)
);

CREATE TABLE reminders (
    reminder_id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT,
    reminder_time DATETIME NOT NULL,
    message TEXT,
    FOREIGN KEY (task_id) REFERENCES tasks(task_id)
);

SELECT * FROM users;
SELECT * FROM activities;
SELECT * FROM tasks;
SELECT * FROM reminders;