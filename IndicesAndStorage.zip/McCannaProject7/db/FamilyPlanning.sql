DROP DATABASE IF EXISTS familyplanning;

CREATE DATABASE familyplanning;

USE  familyplanning;


CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE activities (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_time DATETIME,
    end_time DATETIME,
    frequency ENUM('Daily', 'Weekly', 'Monthly', 'Yearly'),
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE TABLE tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    activity_id INT,
    assigned_to INT,
    status ENUM('Not Started', 'In Progress', 'Completed', 'On Hold'),
    due_date DATETIME,
    FOREIGN KEY (activity_id) REFERENCES activities(activity_id),
    FOREIGN KEY (assigned_to) REFERENCES users(user_id)
);

CREATE TABLE reminders (
    reminder_id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT,
    reminder_time DATETIME,
    message TEXT,
    FOREIGN KEY (task_id) REFERENCES tasks(task_id)
);
