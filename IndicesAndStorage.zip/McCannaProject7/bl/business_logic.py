from dal.database_access import DatabaseAccess

class BusinessLogic:
    def __init__(self):
        self.db_access = DatabaseAccess()

    def add_user(self, username, password_hash):
        self.db_access.connect()
        query = "INSERT INTO users (username, password_hash) VALUES (%s, %s)"
        self.db_access.execute_query(query, (username, password_hash))
        self.db_access.connection.commit()
        self.db_access.disconnect()

    def add_activity(self, title, description, start_time, end_time, frequency, created_by):
        self.db_access.connect()
        query = """
        INSERT INTO activities (title, description, start_time, end_time, frequency, created_by)
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        self.db_access.execute_query(query, (title, description, start_time, end_time, frequency, created_by))
        self.db_access.connection.commit()
        self.db_access.disconnect()

    def assign_task(self, activity_id, assigned_to, due_date):
        self.db_access.connect()
        query = """
        INSERT INTO tasks (activity_id, assigned_to, due_date, status)
        VALUES (%s, %s, %s, 'pending')
        """
        self.db_access.execute_query(query, (activity_id, assigned_to, due_date))
        self.db_access.connection.commit()
        self.db_access.disconnect()

    def update_task_status(self, task_id, status):
        self.db_access.connect()
        query = "UPDATE tasks SET status = %s WHERE task_id = %s"
        self.db_access.execute_query(query, (status, task_id))
        self.db_access.connection.commit()
        self.db_access.disconnect()

    def set_reminder(self, task_id, reminder_time, message):
        self.db_access.connect()
        query = """
        INSERT INTO reminders (task_id, reminder_time, message)
        VALUES (%s, %s, %s)
        """
        self.db_access.execute_query(query, (task_id, reminder_time, message))
        self.db_access.connection.commit()
        self.db_access.disconnect()