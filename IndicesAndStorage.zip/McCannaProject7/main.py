from pl.presentation_logic import main_menu

def main():
    print("Welcome to the Family Planning Application.")
    main_menu()

if __name__ == "__main__":
    main()