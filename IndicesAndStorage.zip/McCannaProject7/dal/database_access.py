import mysql.connector
from mysql.connector import Error

class DatabaseAccess:
    def __init__(self):
        self.connection = None
        self.cursor = None
        self.cache = {}

    def connect(self):
        try:
            self.connection = mysql.connector.connect(
                host='localhost',
                database='FamilyPlanning',
                user='user',
                password='password'
            )
            if self.connection.is_connected():
                db_info = self.connection.get_server_info()
                print(f"Connected to MySQL Server version {db_info}")
                self.cursor = self.connection.cursor()
        except Error as e:
            print(f"Error while connecting to MySQL: {e}")

    def disconnect(self):
        if self.connection.is_connected():
            self.cursor.close()
            self.connection.close()
            print("MySQL connection is closed")

    def execute_query(self, query, params=None):
        try:
            self.cursor.execute(query, params)
            result = self.cursor.fetchall()
            return result
        except Error as e:
            print(f"Error: {e}")

    def execute_procedure(self, procedure_name, params=None):
        try:
            self.cursor.callproc(procedure_name, params)
            result = []
            for result_set in self.cursor.stored_results():
                result.extend(result_set.fetchall())
            return result
        except Error as e:
            print(f"Error: {e}")

    def clear_cache(self):
        self.cache = {}

    # Caching functionality for specific queries
    def get_cached_query(self, query, params=None):
        key = (query, tuple(params) if params else None)
        if key in self.cache:
            return self.cache[key]
        else:
            result = self.execute_query(query, params)
            self.cache[key] = result
            return result

