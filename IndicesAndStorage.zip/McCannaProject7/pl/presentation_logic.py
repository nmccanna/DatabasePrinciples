from bl.business_logic import BusinessLogic

def main_menu():
    logic = BusinessLogic()
    while True:
        print("\nFamily Planning Application")
        print("1. Add user")
        print("2. Add activity")
        print("3. Assign task")
        print("4. Update task status")
        print("5. Set reminder")
        print("6. Exit")
        choice = input("Enter choice: ")

        if choice == '1':
            username = input("Enter username: ")
            password = input("Enter password: ")
            logic.add_user(username, password)
            print("User added successfully.")
        elif choice == '2':
            title = input("Enter activity title: ")
            description = input("Enter activity description: ")
            start_time = input("Enter start time (YYYY-MM-DD HH:MM:SS): ")
            end_time = input("Enter end time (YYYY-MM-DD HH:MM:SS): ")
            frequency = input("Enter frequency (daily, weekly, monthly): ")
            created_by = input("Enter user ID of creator: ")
            logic.add_activity(title, description, start_time, end_time, frequency, created_by)
            print("Activity added successfully.")
        elif choice == '3':
            activity_id = input("Enter activity ID: ")
            assigned_to = input("Enter user ID to assign task to: ")
            due_date = input("Enter due date (YYYY-MM-DD HH:MM:SS): ")
            logic.assign_task(activity_id, assigned_to, due_date)
            print("Task assigned successfully.")
        elif choice == '4':
            task_id = input("Enter task ID: ")
            status = input("Enter task status (completed, pending, canceled): ")
            logic.update_task_status(task_id, status)
            print("Task status updated successfully.")
        elif choice == '5':
            task_id = input("Enter task ID for the reminder: ")
            reminder_time = input("Enter reminder time (YYYY-MM-DD HH:MM:SS): ")
            message = input("Enter reminder message: ")
            logic.set_reminder(task_id, reminder_time, message)
            print("Reminder set successfully.")
        elif choice == '6':
            break
        else:
            print("Invalid choice. Please try again.")
            title = input("Enter activity title: ")
            description = input("Enter activity description: ")
            start_time = input("Enter start time (YYYY-MM-DD HH:MM:SS): ")
            end_time = input("Enter end time (YYYY-MM-DD HH:MM:SS): ")
            frequency = input("Enter frequency (daily, weekly, monthly): ")
            created_by = input("Enter user ID of creator: ")
            logic.add_activity(title, description, start_time, end_time, frequency, created_by)
            print("Activity added successfully.")


if __name__ == "__main__":
    main_menu()
