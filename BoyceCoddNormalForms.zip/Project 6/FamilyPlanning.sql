DROP DATABASE IF EXISTS familyplanning;

CREATE DATABASE familyplanning;

USE  familyplanning;


CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    password_hash VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Activities (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    frequency ENUM('daily', 'weekly', 'monthly', 'once') NOT NULL,
    created_by INT NOT NULL,
    FOREIGN KEY (created_by) REFERENCES Users(user_id)
);

CREATE TABLE Tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    activity_id INT NOT NULL,
    assigned_to INT NOT NULL,
    status ENUM('completed', 'pending', 'canceled') DEFAULT 'pending',
    due_date DATETIME,
    FOREIGN KEY (activity_id) REFERENCES Activities(activity_id),
    FOREIGN KEY (assigned_to) REFERENCES Users(user_id)
);

CREATE TABLE Reminders (
    reminder_id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT NOT NULL,
    reminder_time DATETIME NOT NULL,
    message TEXT,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id)
);

CREATE VIEW CalendarView AS
SELECT a.title, a.description, t.status, t.due_date, u.username
FROM Activities a
JOIN Tasks t ON a.activity_id = t.activity_id
JOIN Users u ON t.assigned_to = u.user_id
ORDER BY t.due_date;
